<?php 
class M_pengaduan extends CI_MODEL{

    function tampil_pengaduan(){
     $user_id= $this->session->userdata('idadmin');
        $hsl=$this->db->query("select * from pengaduan where id_user='$user_id'");
        return $hsl;
    }
}