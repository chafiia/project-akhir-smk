<?php
class M_laporan_jurnal extends CI_Model{
function jurnal_harian($id,$tanggal1,$tanggal2){
    $hsl=$this->db->query("SELECT * FROM `tbl_jurnal` join tbl_siswa on tbl_jurnal.nis=tbl_siswa.nis join tbl_magang on tbl_jurnal.nis =tbl_magang.nis join tbl_jurusan on tbl_siswa.jurusan = tbl_jurusan.id_jurusan join tbl_dudi on tbl_magang.id_dudi = tbl_dudi.id_dudi where tbl_jurnal.nis ='$id' and (tbl_jurnal.tanggal between '$tanggal1' and '$tanggal2')");
		return $hsl;

}
}