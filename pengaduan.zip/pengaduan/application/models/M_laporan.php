<?php
class M_laporan extends CI_Model{

}