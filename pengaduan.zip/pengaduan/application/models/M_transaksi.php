<?php
class M_Transaksi extends CI_Model{

	function tampil_penjualan(){
		$hsl = $this->db->query("SELECT * FROM tbl_jual order by jual_nofak asc");
		return $hsl;
	}
	
}