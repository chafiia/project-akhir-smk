<?php
class M_siswa extends CI_Model{
		public $_table = 'tbl_guru';
	// primary key column
	public $primary_key = 'id_guru';
function __construct(){
	parent::__construct();
}


	function hapus_suplier($kode){
		$hsl=$this->db->query("DELETE FROM tbl_suplier where suplier_id='$kode'");
		return $hsl;
	}

	function update_suplier($kode,$nama,$alamat,$notelp){
		$hsl=$this->db->query("UPDATE tbl_suplier set suplier_nama='$nama',suplier_alamat='$alamat',suplier_notelp='$notelp' where suplier_id='$kode'");
		return $hsl;
	}
	public function like_query($search) {
		return $this->db->query("
			SELECT 
				*
			FROM
				tbl_siswa 
			WHERE
				id_siswa LIKE '%$search%'
			OR
				nama_siswa LIKE '%$search%'
		")->result_array();
		 return $this->db->get()->result_array();
	}
public function getDataSiswa($search)
    {
       $this->db->select('*');
        $this->db->from('tbl_siswa');
        $this->db->join('tbl_jurusan ', 'tbl_siswa.jurusan=tbl_jurusan.id_jurusan');
        $this->db->join('tbl_gelombang', 'tbl_siswa.id_gelombang=tbl_gelombang.gelombang');
        
        $this->db->like('tbl_siswa.nama_siswa', $search);
       
        return $this->db->get()->result_array();
    
      
    }
	function tampil_siswa(){
		$hsl=$this->db->query("SELECT * FROM tbl_siswa JOIN tbl_jurusan on tbl_siswa.jurusan=tbl_jurusan.id_jurusan JOIN tbl_gelombang on tbl_siswa.id_gelombang = tbl_gelombang.gelombang");
		return $hsl;
	}

	function simpan_siswa($nis,$nama,$alamat,$notelp, $kelas,$jurusan,$gelombang,$tgllahir,$tempat_lahir,$nama_ortu,$alamat_ortu,$hp_ortu,$password){
		$hsl=$this->db->query("INSERT INTO tbl_siswa(nis,nama_ortu,alamat_ortu,hp_ortu,nama_siswa,alamat,tempat_lahir,tanggal_lahir,no_telp,kelas,jurusan,id_gelombang,password) VALUES ('$nis','$nama_ortu','$alamat_ortu','$hp_ortu','$nama','$alamat','$tempat_lahir','$tgllahir','$notelp','$kelas','$jurusan','$gelombang','$password')");
		return $hsl;
	}

}