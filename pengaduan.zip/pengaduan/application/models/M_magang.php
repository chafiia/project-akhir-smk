<?php
class M_magang extends CI_Model{

	function hapus_pengajuan($kode){
		$hsl=$this->db->query("DELETE FROM tbl_magang where id_magang='$kode'");
		return $hsl;
	}
	function hapus($kode){
		$hsl=$this->db->query("DELETE FROM tbl_magang where id_magang='$kode'");
		return $hsl;
	}
	function update_pengajuan($id_magang,$id_siswa,$gelombang,$dudi,$status){
		$user_id=$this->session->userdata('idadmin');
		$hsl=$this->db->query("UPDATE tbl_magang SET nis='$id_siswa',id_gelombang='$gelombang',id_dudi='$dudi' ,status='$status' WHERE id_magang='$id_magang'");
		return $hsl;
	}

	function tampil_pengajuan(){
		$hsl=$this->db->query("select * from tbl_magang join tbl_siswa on tbl_magang.nis=tbl_siswa.nis join tbl_gelombang on tbl_magang.id_gelombang=tbl_gelombang.gelombang JOIN tbl_dudi on tbl_magang.id_dudi=tbl_dudi.id_dudi where tbl_magang.status='pengajuan' GROUP by id_magang");
		return $hsl;
	}
function tampil_magang(){
		$hsl=$this->db->query("select * from tbl_magang join tbl_siswa on tbl_magang.nis=tbl_siswa.nis join tbl_gelombang on tbl_magang.id_gelombang=tbl_gelombang.gelombang JOIN tbl_dudi on tbl_magang.id_dudi=tbl_dudi.id_dudi where tbl_magang.status='diterima' GROUP by id_magang");
		return $hsl;
	}
	
	function simpan_pengajuan($nis,$gelombang,$dudi,$status){
		$user_id=$this->session->userdata('idadmin');
		$hsl=$this->db->query("INSERT INTO tbl_magang(nis,id_gelombang,id_dudi,status) VALUES ('$nis','$gelombang','$dudi','$status')");
		return $hsl;
	}

	function get_barang($kobar){
		$hsl=$this->db->query("SELECT * FROM tbl_barang where barang_id='$kobar'");
		return $hsl;
	}

	

}