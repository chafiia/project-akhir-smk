<?php
 include_once APPPATH . '/third_party/fpdf/fpdf.php';

class PDF extends FPDF
{
    // Page header
    function Header()
    {
      // Logo
     
    	// Arial bold 15
    	$this->SetFont('Times','B',15);
    	// Move to the right
    	// $this->Cell(60);
    	// Title
        $this->Cell(200,8,'LAPORAN KEGIATAN KERJA SISWA',0,1,'C');
        
    	// Line break
    	$this->Ln(5);

        $this->SetFont('Times','BU',12);
        for ($i=0; $i < 10; $i++) {
            $this->Cell(185,0,'',1,1,'C');
        }

        $this->Ln(1);

        
        $this->Ln(5);

        $this->SetFont('Times','B',9.5);

        // header tabel
        $this->cell(10,7,'NO.',1,0,'C');
        $this->cell(25,7,'TANGGAL',1,0,'C');
        $this->cell(25,7,'UNIT KERJA',1,0,'C');
        $this->cell(45,7,'NAMA KEGIATAN',1,0,'C');
        $this->cell(30,7,'FOTO',1,0,'C');
     
        $this->cell(25,7,'CATATAN ',1,0,'C');
        $this->cell(25,7,'PARAF',1,1,'C');

    }

    // Page footer
    function Footer()
    {
    	// Position at 1.5 cm from bottom
    	$this->SetY(-15);
    	// Arial italic 8
    	$this->SetFont('Arial','I',8);
    	// Page number
    	$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    }
}

// ambil dari database


$pdf = new PDF('p', 'mm', [210, 330]);
$pdf->AliasNbPages();
$pdf->AddPage();

// set font
$pdf->SetFont('Times','',9);

// set penomoran
$no=0;
   foreach ($data->result_array() as $i) {
        $no++;
        $nis=$i['nama_siswa'];
        $tgl=$i['tanggal'];
        $unit=$i['unit_kerja'];
        $nama_kegiatan=$i['nama_kegiatan'];
        $catatan=$i['catatan_instruktur'];
        $status=$i['status_kehadiran'];
        $foto=$i['foto_kegiatan'];
      

    // hitung anggota
   
    $pdf->cell(10, 9, $no . '.', 1, 0, 'C');
    $pdf->cell(25, 9, $tgl, 1, 0, 'C');
    $pdf->cell(25, 9,$unit , 1, 0, 'L');
    $pdf->cell(45, 9,$nama_kegiatan , 1, 0, 'C');
    $pdf->cell(30, 9,$foto , 1, 0, 'C');

    $pdf->cell(25, 9,$catatan, 1, 0, 'C');
    $pdf->cell(25, 9,'           ', 1, 1, 'C');

}

	$pdf->Ln(10);

$pdf->Output();
?>
