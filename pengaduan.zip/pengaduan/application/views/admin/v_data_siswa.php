<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" 
    <meta name="author" content="Subur Anjar Kasi">

    <title>Selamat datang Di Sistem Informasi Magang</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url().'assets/css/bootstrap.min.css'?>" rel="stylesheet">
	<link href="<?php echo base_url().'assets/css/style.css'?>" rel="stylesheet">
	<link href="<?php echo base_url().'assets/css/font-awesome.css'?>" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo base_url().'assets/css/4-col-portfolio.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/css/dataTables.bootstrap.min.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/css/jquery.dataTables.min.css'?>" rel="stylesheet">

</head>

<body>

    <!-- Navigation -->
   <?php 
        $this->load->view('admin/menu');
   ?>

    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Data
                    <small>Siswa</small>
                    <div class="pull-right"><a href="#" class="btn btn-sm btn-success" data-toggle="modal" data-target="#largeModal"><span class="fa fa-plus"></span> Tambah Data Siswa</a></div>
                </h1>
            </div>
        </div>
        <!-- /.row -->
        <!-- Projects Row -->
        <div class="row">
            <div class="col-lg-12">
            <table class="table table-bordered table-condensed" style="font-size:12px;" id="mydata">
                <thead>
                    <tr>
                        <th style="text-align:center;width:40px;">No</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                         <th>Kelas</th>
                          <th>Jurusan</th>
                           <th>Gelombang</th>
                            <th>Tahun Ajaran</th>
                        <th>Alamat</th>
                        <th>Tempat lahir</th>
                        <th>Tanggal Lahir</th>
                        <th>Email</th>
                        <th>No Telp</th>
                        <th style="width:140px;text-align:center;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                    $no=0;
                    foreach ($data->result_array() as $a):
                        $no++;
                        $id=$a['id_siswa'];
                        $nis=$a['nis'];
                        $nama=$a['nama_siswa'];
                        $kelas=$a['kelas'];
                        $jurusan=$a['nama_jurusan'];
                         $gelombang=$a['gelombang'];
                           $tahunajaran=$a['tahun_ajaran'];
                             $alamat=$a['alamat'];
                               $tempatlahir=$a['tempat_lahir'];
                                 $tgllahir=$a['tanggal_lahir'];
                                 $nama_ortu=$a['nama_ortu'];
                                   $no_telp=$a['no_telp'];
                ?>
                    <tr>
                        <td style="text-align:center;"><?php echo $no;?></td>
                       
                        <td><?php echo $nis;?></td>
                        <td><?php echo $nama;?></td>
                        <td><?php echo $kelas;?></td>
                          <td><?php echo $jurusan;?></td>
                        <td><?php echo $gelombang;?></td>
                        <td><?php echo $tahunajaran;?></td>
                        <td><?php echo $alamat;?></td>
                        <td><?php echo $tempatlahir;?></td>
                        <td><?php echo $tgllahir;?></td>
                        <td><?php echo $nama_ortu;?></td>
                         <td><?php echo $no_telp;?></td>
                        <td style="text-align:center;">
                            <a class="btn btn-xs btn-warning" href="#modalEditSiswa<?php echo $id?>" data-toggle="modal" title="Edit"><span class="fa fa-edit"></span> Edit</a>
                            <a class="btn btn-xs btn-danger" href="#modalHapusPelanggan<?php echo $id?>" data-toggle="modal" title="Hapus"><span class="fa fa-close"></span> Hapus</a>
                        </td>
                    </tr>
                <?php endforeach;?>
                </tbody>
            </table>
            </div>
        </div>
        <!-- /.row -->
        <!-- ============ MODAL ADD =============== -->
        <div class="modal fade" id="largeModal" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="modal-title" id="myModalLabel">Tambah Data Siswa</h3>
            </div>
            <form class="form-horizontal" method="post" action="<?php echo base_url().'admin/siswa/tambah_siswa'?>">
                <div class="modal-body">
                    <input name="password" class="form-control" value ="123456" type="hidden" style="width:280px;" required>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >NIS</label>
                        <div class="col-xs-9">
                            <input name="nis" class="form-control" type="text" placeholder="NIS." style="width:280px;" required>
                        </div>
                    </div>
                        
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Nama Siswa</label>
                        <div class="col-xs-9">
                            <input name="nama_siswa" class="form-control" type="text" placeholder="nama siswa" style="width:280px;" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >No.Telp</label>
                        <div class="col-xs-9">
                            <input name="no_telp" class="form-control datepicker" type="text" placeholder="tempat lahir    " style="width:280px;" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Kelas</label>
                        <div class="col-xs-9">
                            <input name="kelas" class="form-control" type="text" placeholder="Kelas" style="width:280px;" required>
                        </div>
                    </div>   
                   <div class="form-group">
                            <label class="control-label col-xs-3" >Jurusan</label>
                            <div class="col-xs-9">
                                <select name="jurusan" class="selectpicker show-tick form-control" data-live-search="true" title="Pilih jurusan" data-width="80%" placeholder="Pilih jurusan" required>
                                <?php foreach ($kat2->result_array() as $k) {
                                    $id_kat2=$k['id_jurusan'];
                                    $nama_kat2=$k['nama_jurusan'];
                                    $singkatan_kat2=$k['singkatan'];
                                    ?>
                                        <option value="<?php echo $id_kat2;?>"><?php echo $nama_kat2;?> (<?php echo $singkatan_kat2;?> _</option>
                                <?php }?>
                                    
                                </select>
                            </div>
                        </div>
                       <div class="form-group">
                            <label class="control-label col-xs-3" >Gelombang</label>
                            <div class="col-xs-9">
                                <select name="gelombang" class="selectpicker show-tick form-control" data-live-search="true" title="Pilih Gelombang" data-width="80%" placeholder="Pilih Kategori" required>
                                <?php foreach ($kat->result_array() as $k) {
                                    $id_kat=$k['gelombang'];
                                    $tgl_kat=$k['tanggal_pelaksanaan'];
                                    ?>
                                        <option value="<?php echo $id_kat;?>">Gelombang = &nbsp<?php echo $id_kat;?> Tanggal pelaksanaan : &nbsp<?php echo $tgl_kat;?> </option>
                                <?php }?>
                                    
                                </select>
                            </div>
                        </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Alamat</label>
                        <div class="col-xs-9">
                            <input name="alamat" class="form-control" type="text" placeholder="alamat" style="width:280px;" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Tanggal Lahir</label>
                        <div class="col-xs-9">
                            <div class='input-group date' id='datepicker' style="width:300px;">
                                <input type='text' name="tgl_lahir" class="form-control" value="" placeholder="Tanggal..." required/>
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                    </div>
                      <div class="form-group">
                        <label class="control-label col-xs-3" >Tempat Lahir</label>
                        <div class="col-xs-9">
                            <input name="tempat_lahir" class="form-control datepicker" type="text" placeholder="tempat lahir    " style="width:280px;" required>
                        </div>
                    </div>
                     <div class="form-group">
                        <label class="control-label col-xs-3" >Nama Orang Tua</label>
                        <div class="col-xs-9">
                            <input name="nama_ortu" class="form-control datepicker" type="text" placeholder="email" style="width:280px;" required>
                        </div>
                    </div>
                     <div class="form-group">
                        <label class="control-label col-xs-3" >Alamat Ortu</label>
                        <div class="col-xs-9">
                            <input name="alamat_ortu" class="form-control datepicker" type="text" placeholder="email" style="width:280px;" required>
                        </div>
                    </div>
                     <div class="form-group">
                        <label class="control-label col-xs-3" >No Hp Ortu</label>
                        <div class="col-xs-9">
                            <input name="hp_ortu" class="form-control datepicker" type="text" placeholder="email" style="width:280px;" required>
                        </div>
                    </div>
                </div>
                

                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-info">Simpan</button>
                </div>
            </form>
            </div>
            </div>
        </div>

        <!-- ============ MODAL EDIT =============== -->
        <?php
                    foreach ($data->result_array() as $a) {
                        $id=$a['id_siswa'];
                        $nis=$a['nis'];
                        $nama=$a['nama_siswa'];
                        $kelas=$a['kelas'];
                        $jurusan=$a['jurusan'];
                         $gelombang=$a['gelombang'];
                           $tahunajaran=$a['tahun_ajaran'];
                             $alamat=$a['alamat'];
                               $tempatlahir=$a['tempat_lahir'];
                               
                                   $no_telp=$a['no_telp'];
                                    $tgllahir=$a['tanggal_lahir'];
                    ?>
                <div id="modalEditSiswa<?php echo $id?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
                    <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h3 class="modal-title" id="myModalLabel">Edit Data Siswa</h3>
                    </div>
                    <form class="form-horizontal" method="post" action="<?php echo base_url().'admin/suplier/edit_suplier'?>">
                        <div class="modal-body">
                            <input name="kode" type="hidden" value="<?php echo $id;?>">

                    <div class="form-group">
                        <label class="control-label col-xs-3" >NIS</label>
                        <div class="col-xs-9">
                            <input name="nama" class="form-control" type="text" placeholder="" value="<?php echo $nis;?>" style="width:280px;" required>
                        </div>
                    </div>
                        
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Nama Siswa</label>
                        <div class="col-xs-9">
                            <input name="alamat" class="form-control" type="text" placeholder="Alamat..." value="<?php echo $nama;?>" style="width:280px;" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-xs-3" >No Telp/ HP</label>
                        <div class="col-xs-9">
                            <input name="notelp" class="form-control" type="text" placeholder="No Telp/HP..." value="<?php echo $no_telp;?>" style="width:280px;" required>
                        </div>
                    </div>   

                    <div class="form-group">
                        <label class="control-label col-xs-3" >Kelas</label>
                        <div class="col-xs-9">
                            <input name="notelp" class="form-control" type="text" placeholder="Kelas" value="<?php echo $kelas;?>" style="width:280px;" required>
                        </div>
                    </div>   

                     <div class="form-group">
                            <label class="control-label col-xs-3" >Jurusan</label>
                            <div class="col-xs-9">
                                <select name="jurusan" class="selectpicker show-tick form-control" data-live-search="true" title="Pilih jurusan" data-width="80%" placeholder="Pilih jurusan" required>
                                <?php foreach ($kat2->result_array() as $k) {
                                    $id_kat2=$k['id_jurusan'];
                                    $nama_kat2=$k['nama_jurusan'];
                                    $singkatan_kat2=$k['singkatan'];
                                    ?>
                                        <option value="<?php echo $id_kat2;?>"><?php echo $nama_kat2;?> (<?php echo $singkatan_kat2;?> _</option>
                                <?php }?>
                                    
                                </select>
                            </div>
                        </div>
                       <div class="form-group">
                            <label class="control-label col-xs-3" >Gelombang</label>
                            <div class="col-xs-9">
                                <select name="gelombang" class="selectpicker show-tick form-control" data-live-search="true" title="Pilih Gelombang" data-width="80%" placeholder="Pilih Kategori" required>
                                <?php foreach ($kat->result_array() as $k) {
                                    $id_kat=$k['gelombang'];
                                    $tgl_kat=$k['tanggal_pelaksanaan'];
                                    ?>
                                        <option value="<?php echo $id_kat;?>">Gelombang = &nbsp<?php echo $id_kat;?> Tanggal pelaksanaan : &nbsp<?php echo $tgl_kat;?> </option>
                                <?php }?>
                                    
                                </select>
                            </div>
                        </div>

                         <div class="form-group">
                        <label class="control-label col-xs-3" >Alamat</label>
                        <div class="col-xs-9">
                            <input name="alamat" class="form-control" type="text" placeholder="Alamat" value="<?php echo $alamat;?>" style="width:280px;" required>
                        </div>
                    </div>  
                   
 
                        <div class="modal-footer">
                            <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                            <button type="submit" class="btn btn-info">Update</button>
                        </div>
                    </form>
                </div>
                </div>
                </div>
            <?php
        }
        ?>

        <!-- ============ MODAL HAPUS =============== -->
        <?php
                    foreach ($data->result_array() as $a) {
                       $id=$a['id_siswa'];
                        $nis=$a['nis'];
                        $nama=$a['nama_siswa'];
                        $kelas=$a['kelas'];
                        $jurusan=$a['jurusan'];
                         $gelombang=$a['gelombang'];
                           $tahunajaran=$a['tahun_ajaran'];
                             $alamat=$a['alamat'];
                               $tempatlahir=$a['tempat_lahir'];
                                
                                   $no_telp=$a['no_telp'];
                    ?>
                <div id="modalHapusPelanggan<?php echo $id?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
                    <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h3 class="modal-title" id="myModalLabel">Hapus Suplier</h3>
                    </div>
                    <form class="form-horizontal" method="post" action="<?php echo base_url().'admin/suplier/hapus_suplier'?>">
                        <div class="modal-body">
                            <p>Yakin mau menghapus data..?</p>
                                    <input name="kode" type="hidden" value="<?php echo $id; ?>">
                        </div>
                        <div class="modal-footer">
                            <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                            <button type="submit" class="btn btn-primary">Hapus</button>
                        </div>
                    </form>
                </div>
                </div>
                </div>
            <?php
        }
        ?>

        <!--END MODAL-->

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p style="text-align:center;">Copyright &copy; <?php echo '2020';?> Subur Anjar Kasi</p>
                </div>
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="<?php echo base_url().'assets/js/jquery.js'?>"></script>

    <!-- Bootstrap Core JavaScript -->
   
    <script src="<?php echo base_url().'assets/js/bootstrap.min.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/dataTables.bootstrap.min.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/jquery.dataTables.min.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/moment.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/bootstrap-datetimepicker.min.js'?>"></script>
    <script type="text/javascript">
            $(function () {
                $('#datetimepicker').datetimepicker({
                    format: 'DD MMMM YYYY HH:mm',
                });
                
                $('#datepicker').datetimepicker({
                    format: 'YYYY-MM-DD',
                });
                $('#datepicker2').datetimepicker({
                    format: 'YYYY-MM-DD',
                });

                $('#timepicker').datetimepicker({
                    format: 'HH:mm'
                });
            });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#mydata').DataTable();
        } );
    </script>
    
</body>

</html>
